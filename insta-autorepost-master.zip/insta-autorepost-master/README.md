# insta-autorepost
This script scrapes images from multiple profiles and post them to your profile

### Download the script
```
git clone https://github.com/nishantcoder97/insta-autorepost.git
```

### Install requirements
```
cd insta-autorepost
sudo pip install -r requirements.txt
```
### Run script
```
python3 main.py
```
